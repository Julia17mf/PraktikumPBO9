import java.sql.*;

public class KoneksiDB {
    public Connection getKoneksi() throws ClassNotFoundException, SQLException{
            Class.forName("com.mysql.jdbc.Driver");
        
            //jdbc:mysql://localhost/nama_database
            String url = "jdbc:mysql://localhost/mahasiswa";
            Connection con = DriverManager.getConnection(url, "root", "");
        
        return con;
    }
}
