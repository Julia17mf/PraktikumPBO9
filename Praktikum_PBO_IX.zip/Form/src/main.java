
public class main {

    public static void main(String[] args) throws ClassNotFoundException {
        // TODO code application logic here
        
//       formmhs fm = new formmhs();
//       fm.tesformmhs();
        
        Tampil data = new Tampil();
        data.LihatData();
    }
    
}
